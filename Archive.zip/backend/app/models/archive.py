"""
Archive models - this module is currently unused as archive functionality
is handled by models in document.py (DocumentCategory and ArchiveDocument).
"""

# All archive functionality is handled by:
# - DocumentCategory in app.models.document
# - ArchiveDocument in app.models.document
# This file is kept for future archive-specific features 