"""
Services package for Romanian Public Administration Platform
Contains business logic and external service integrations.
"""

# Business logic and service layer 